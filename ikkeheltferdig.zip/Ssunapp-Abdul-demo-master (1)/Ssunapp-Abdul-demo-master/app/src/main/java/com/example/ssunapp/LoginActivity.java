package com.example.ssunapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText et_usermail, et_password;
    Button btn_sign, btn_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        DataBase dbsqlite = new DataBase(this);

        et_usermail = findViewById(R.id.login_et_mail);
        et_password = findViewById(R.id.login_et_pass);
        btn_signup = findViewById(R.id.login_btn_signup);
        btn_sign = findViewById(R.id.login_btn_sign);

        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String mail_login = et_usermail.getText().toString().trim();
                String pass_login = et_password.getText().toString().trim();

                // Validation checks
                if (mail_login.isEmpty() || pass_login.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Email or Password field is empty, try Again", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean res_login = dbsqlite.login_user(mail_login, pass_login);
                if (res_login) {
                    User currentUser = dbsqlite.getUserByEmail(mail_login);
                    if (currentUser != null) {
                        // Save email and name in shared preferences
                        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("user_email", mail_login);
                        editor.putString("user_name", currentUser.getUser_name()); // Save the user's name
                        editor.apply();

                        Toast.makeText(getApplicationContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(), "User not found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RegActivity.class);
                startActivity(intent);
            }
        });
    }
}
