package com.example.ssunapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.util.Log;
public class ViewNotActivity extends AppCompatActivity {

    EditText vnote_title;
    EditText vnote_fag;
    EditText vnote_larer;
    EditText vnote_desc;
    ImageView vnote_img;
    FloatingActionButton fabbtn;
    DataBase dbsqlite;
    private static final int PICK_IMAG_REQ_CODE = 1;
    private Uri imagUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_not);

        dbsqlite = new DataBase(this);
        vnote_title = findViewById(R.id.viewnot_activ_et_title);
        vnote_fag = findViewById(R.id.viewnot_activ_et_fag);
        vnote_larer = findViewById(R.id.viewnot_activ_et_larer);
        vnote_desc = findViewById(R.id.viewnot_activ_et_desc);
        vnote_img = findViewById(R.id.viewnot_activ_imgv);
        fabbtn = findViewById(R.id.view_activ_fbut_addnot);


        vnote_img.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, PICK_IMAG_REQ_CODE);
        });

        fabbtn.setOnClickListener(view -> {
            String title = vnote_title.getText().toString();
            String fag = vnote_fag.getText().toString();
            String teacher = vnote_larer.getText().toString();
            String desc = vnote_desc.getText().toString();
            String image = (imagUri != null) ? imagUri.toString() : null;

            // Retrieve the user email from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            String userEmail = sharedPreferences.getString("user_email", "Unknown Publisher");
            String userName = sharedPreferences.getString("user_name", "Unknown Publisher");
            Log.d("ViewNotDebug", "Inserting Note with Publisher: " + userName);

            // Use userName or userEmail as publishedBy, based on your preference
            Noter record = new Noter(title, fag, teacher, desc, image, userEmail); // or userName

            boolean res = dbsqlite.Insert_not(record);
            if (res) {
                Toast.makeText(getApplicationContext(), "Notat lagret", Toast.LENGTH_SHORT).show();
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                finish();
            } else {
                Toast.makeText(getApplicationContext(), "Feil ved lagring av notat", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAG_REQ_CODE && resultCode == RESULT_OK && data != null) {
            imagUri = data.getData();
            vnote_img.setImageURI(imagUri);
        }
    }
}
