package com.example.ssunapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import com.bumptech.glide.Glide;

public class UserProfileActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    ImageView ivProfilePic;

    EditText etName, etEmail, etPhone;
    Button btnSave;
    DataBase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Initialize views
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        btnSave = findViewById(R.id.btnSave);
        ivProfilePic = findViewById(R.id.ivProfilePic);

        // Initialize database
        database = new DataBase(this);

        // Load user data from database
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String userEmail = sharedPreferences.getString("user_email", "");
        User currentUser = database.getUserByEmail(userEmail);
        if (currentUser != null) {
            etName.setText(currentUser.getUser_name());
            etEmail.setText(currentUser.getUser_mail());
            etPhone.setText(currentUser.getUserPhone());
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
        }

        // Set click listener for the profile picture
        ivProfilePic.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String phone = etPhone.getText().toString();

            // Validate fields before updating
            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(UserProfileActivity.this, "Name and phone cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!email.equals(userEmail)) {
                Toast.makeText(UserProfileActivity.this, "Email cannot be changed", Toast.LENGTH_SHORT).show();
                return;
            }

            User updatedUser = new User(name, email, phone);
            boolean success = database.updateUser(updatedUser);
            if (success) {
                Toast.makeText(UserProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(UserProfileActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();
            Glide.with(this).load(selectedImageUri).into(ivProfilePic);
        }
    }
}
