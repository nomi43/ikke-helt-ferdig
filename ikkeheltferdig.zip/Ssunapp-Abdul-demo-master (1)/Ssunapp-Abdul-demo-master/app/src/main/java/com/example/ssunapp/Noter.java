package com.example.ssunapp;

public class Noter {
    private int noter_id;
    private String noter_title;
    private String noter_fag;
    private String noter_larer;
    private String noter_des;
    private String noter_img;
    private String publishedBy; // New field to store the publisher's information

    public Noter() {
    }

    public Noter(int noter_id, String noter_title, String noter_fag, String noter_larer, String noter_des, String noter_img, String publishedBy) {
        this.noter_id = noter_id;
        this.noter_title = noter_title;
        this.noter_fag = noter_fag;
        this.noter_larer = noter_larer;
        this.noter_des = noter_des;
        this.noter_img = noter_img;
        this.publishedBy = publishedBy;
    }

    public Noter(String noter_title, String noter_fag, String noter_larer, String noter_des, String noter_img, String publishedBy) {
        this.noter_title = noter_title;
        this.noter_fag = noter_fag;
        this.noter_larer = noter_larer;
        this.noter_des = noter_des;
        this.noter_img = noter_img;
        this.publishedBy = publishedBy;
    }


    public Noter(String noter_title, String noter_fag, String noter_larer, String noter_des) {
        this.noter_title = noter_title;
        this.noter_fag = noter_fag;
        this.noter_larer = noter_larer;
        this.noter_des = noter_des;
    }

    public int getNoter_id() {
        return noter_id;
    }

    public void setNoter_id(int noter_id) {
        this.noter_id = noter_id;
    }

    public String getNoter_title() {
        return noter_title;
    }

    public void setNoter_title(String noter_title) {
        this.noter_title = noter_title;
    }

    public String getNoter_fag() {
        return noter_fag;
    }



    public void setNoter_fag(String noter_fag) {
        this.noter_fag = noter_fag;
    }

    public String getNoter_larer() {
        return noter_larer;
    }

    public void setNoter_larer(String noter_larer) {
        this.noter_larer = noter_larer;
    }

    public String getNoter_des() {
        return noter_des;
    }

    public void setNoter_des(String noter_des) {
        this.noter_des = noter_des;
    }

    public String getNoter_img() {
        return noter_img;
    }

    public void setNoter_img(String noter_img) {
        this.noter_img = noter_img;
    }
    public String getPublishedBy() {
        return publishedBy;
    }

    public void setPublishedBy(String publishedBy) {
        this.publishedBy = publishedBy;
    }


    @Override
    public String toString() {
        return "Noter{" +
                "noter_id=" + noter_id +
                ", noter_title='" + noter_title + '\'' +
                ", noter_fag='" + noter_fag + '\'' +
                ", noter_larer='" + noter_larer + '\'' +
                ", noter_des='" + noter_des + '\'' +
                ", noter_img='" + noter_img + '\'' +
                '}';
    }
}
