package com.example.ssunapp;

public class User {
    private int id_user;
    private String user_name;
    private String user_mail;
    private String user_pass;
    private String userPhone;

    public User(int id_user, String user_name, String user_mail, String user_pass, String userPhone) {
        this.id_user = id_user;
        this.user_name = user_name;
        this.user_mail = user_mail;
        this.user_pass = user_pass;
        this.userPhone = userPhone;
    }

    public User(String user_name, String user_mail, String user_pass, String userPhone) {
        this.user_name = user_name;
        this.user_mail = user_mail;
        this.user_pass = user_pass;
        this.userPhone = userPhone;
    }

    public User(String user_name, String user_mail, String user_pass) {
        this.user_name = user_name;
        this.user_mail = user_mail;
        this.user_pass = user_pass;
    }

    public User(String user_mail, String user_pass) {
        this.user_mail = user_mail;
        this.user_pass = user_pass;
    }

    // Getters and setters
    public int getId() {
        return id_user;
    }

    public void setId(int id_user) {
        this.id_user = id_user;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_mail() {
        return user_mail;
    }

    public void setUser_mail(String user_mail) {
        this.user_mail = user_mail;
    }

    public String getUser_pass() {
        return user_pass;
    }

    public void setUser_pass(String user_pass) {
        this.user_pass = user_pass;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    @Override
    public String toString() {
        return "User{" +
                "id_user=" + id_user +
                ", user_name='" + user_name + '\'' +
                ", user_mail='" + user_mail + '\'' +
                ", user_pass='" + user_pass + '\'' +
                ", userPhone='" + userPhone + '\'' +
                '}';
    }
}
